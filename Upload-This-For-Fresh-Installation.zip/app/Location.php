<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Location extends Model
{
    /**
     * @var mixed
     */
    public $timestamps = false;

    /**
     * @return mixed
     */
    public function restaurants()
    {
        return $this->hasMany('App\Restaurant');
    }

    /**
     * @return mixed
     */
    public function togglePopular()
    {
        $this->is_popular = !$this->is_popular;
        return $this;
    }

    /**
     * @return mixed
     */
    public function toggleActive()
    {
        $this->is_active = !$this->is_active;
        return $this;
    }
}
